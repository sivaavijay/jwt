package com.project.jwtwithdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtwithdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
