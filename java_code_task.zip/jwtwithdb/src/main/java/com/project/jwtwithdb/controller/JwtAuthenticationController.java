package com.project.jwtwithdb.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.project.jwtwithdb.config.JwtTokenUtil;
import com.project.jwtwithdb.model.DAOUser;
import com.project.jwtwithdb.model.JwtRequest;
import com.project.jwtwithdb.model.JwtResponse;
import com.project.jwtwithdb.model.UserDTO;
import com.project.jwtwithdb.repository.UserDao;
import com.project.jwtwithdb.service.JwtUserDetailsService;

@RestController
@CrossOrigin
public class JwtAuthenticationController {

	//This object is used to validate username and password from database
	@Autowired
	private AuthenticationManager authenticationManager;

	//This is used for generating token
	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	//This is used to check user in database or not
	@Autowired
	private JwtUserDetailsService userDetailsService;
	
	@Autowired 
	private UserDao userRepository;
	
	//Login URL
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {

		authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());

		final UserDetails userDetails = userDetailsService
				.loadUserByUsername(authenticationRequest.getUsername());

		final String token = jwtTokenUtil.generateToken(userDetails);

		return ResponseEntity.ok(new JwtResponse(token));
	}

	
	//Register URL
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ResponseEntity<?> saveUser(@RequestBody UserDTO user) throws Exception {
		return ResponseEntity.ok(userDetailsService.save(user));
	}
	
	//Validates and throws expection if something wrong
	private void authenticate(String username, String password) throws Exception {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}
	}
	
	
	/*######################################################################################################################
	Function Name: getCount
	Return 	 Type: long
	Request  Type: GET
	Parameters   : - 
	Written  By  : SIVAA V
	Last Modified: 21-09-2021
	Usage		 : This function is used to return count of users
	#####################################################################################################################*/		

	@RequestMapping(value="/getcount",method=RequestMethod.GET)
	public long getCount()
	{
		return userRepository.count();
	}


	/*######################################################################################################################
	Function Name: getData
	Return 	 Type: Iterable
	Request  Type: GET
	Parameters   : - 
	Written  By  : SIVAA V
	Last Modified: 21-09-2021
	Usage		 : This function is used to return user data from user table
	#####################################################################################################################*/		

	
	@RequestMapping(value="/getdata",method=RequestMethod.GET)
	public Iterable<DAOUser> getData()
	{
		return userRepository.findAll();
	}
}
