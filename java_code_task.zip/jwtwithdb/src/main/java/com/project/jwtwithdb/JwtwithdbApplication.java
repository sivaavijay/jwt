package com.project.jwtwithdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtwithdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtwithdbApplication.class, args);
	}

}
